# dsh-code-ui

在 DeepSeek Harness（DSH）里的 **Cursor 风格 AI 代码编辑器**插件：文件树、多标签页编辑、语法高亮、引用/翻译给 AI。

它把 Cursor 那种「边看代码、边跟 AI 对话」的体验搬进 DSH：一个带活动栏、文件树、多标签页编辑器的代码工作区。**v1.2.0 起支持两种布局**：右侧停靠（code UI 固定占屏幕右侧、与聊天并排，默认）或悬浮窗口（可拖拽浮动窗口，内嵌 AI 输入框），插件卡片里可随时切换。

## 功能

- **双布局可选**：右侧停靠（默认，与聊天并排） / 悬浮窗口（可拖拽缩放），插件卡片切换、即时生效
- **切换按钮可选**：会话头 `⌨ code UI` 按钮（默认） / 悬浮模式条，与布局任意组合
- **界面模式可持久化**：code UI / dsh UI（隐藏编辑器回归原生界面），所有入口切换均同步记忆
- **Cursor 风格工作区**：活动栏 + 文件树侧边栏 + 多标签页编辑器 + 状态栏
- **侧栏收起与调宽**：« 按钮 / 📁 三态 / 拖到最窄自动收起，» 把手展开，右缘拖拽调宽
- **停靠面板拖宽**：左缘手柄实时调整面板宽度，DSH 界面自动跟随
- **语法高亮**：内联轻量 tokenizer，覆盖 JS/TS/Python/HTML/CSS 等，token 色随主题两套配色
- **文件浏览与编辑**：展开目录、打开文件、直接编辑、`Ctrl+S` 保存写回磁盘；外部修改自动同步
- **选中代码右键**：
  - 📋 复制
  - 📥 粘贴到备注
  - 📝 添加备注
  - 🌐 翻译（创建翻译引用，交给 AI 翻译）
  - 🔗 引用给 AI
- **引用 chip**：引用后输入框上方显示 `文件名(起行-止行)` + ✕，删除引用
- **内嵌 AI 输入框**（悬浮布局）：直接输入、`Ctrl+Enter` 发送；发送时不粘贴引用正文，只附一行引用指针，内容由 AI 调用 `get_referenced_snippets` 工具读取
- **主题四态**：跟随 DSH（默认）/ 跟随系统 / 浅色 / 深色，插件卡片切换
- **以此文件夹为根**：文件浏览器里可选任意目录作为工作区根
- **检查更新 / 一键更新**：设置 → 插件 → 插件配置 中的 dsh-code-ui 卡片，支持在线检查 npm 新版本并一键更新；未发布/开发期可填本地 `.tgz` 路径安装（pnpm 流式进度展示，失败自动归类给出建议，完成后提示重启 DSH 生效）

## 安装

通过 `dsh plugin` 一键安装（已声明 `dsh.bundle`）：

```bash
dsh plugin --profile web add dsh-code-ui
```

安装完成后重启 DSH，会话标题栏出现 `⌨ code UI` 按钮，点击即可打开右侧停靠的编辑器（默认）；也可在插件卡片改为悬浮窗口布局与悬浮模式条切换。

或手动安装：

```bash
cd $DSH_HOME/profiles          # Windows: %USERPROFILE%\.dsh\profiles
npm install dsh-code-ui
```

然后在 `cordis.patch.yml` 追加：

```yaml
- insert:
    - id: dsh-code-ui
      name: 'dsh-code-ui'
```

## 使用

1. 点会话标题栏 `⌨ code UI` 按钮打开编辑器（默认右侧停靠；悬浮布局则用顶部悬浮模式条）
2. 在文件树/浏览器里打开文件
3. 选中代码右键 → 引用 / 翻译 / 备注 / 复制
4. 悬浮布局底部输入框直接发消息（`Ctrl+Enter` 发送）；停靠布局用 DSH 原生输入条，引用只以标签显示，正文由 AI 工具读取
5. 也可对 AI 说「读取我引用的代码」，AI 会调用 `get_referenced_snippets` 工具

## 目录结构

```
dsh-code-ui/
├── package.json      # 包声明（含 dsh.bundle.patch / dsh.client）
├── lib/
│   ├── index.js      # Host 端：connection.rpc 文件/引用/备注 RPC + get_referenced_snippets 工具
│   └── client.js     # Client 端：__ModuleLoader__ + 编辑器 UI
└── cordis.patch.yml  # bundle 插接层
```

纯 JavaScript 手写实现，无需构建，可直接 `npm publish`。

## 实现说明

- **Host↔Client RPC**：Host 通过 `connection.rpc.handle("/dsh-code-ui", handler)` 注册文件系统/引用/备注端点；Client 通过 `connection.rpc.call("/dsh-code-ui", endpoint, payload)` 调用。RPC 返回值遵循 DSH 的 `RpcResult` 协议（`{ ok: true, value }` / `{ ok: false, error }`）。
- **模型工具**：注册 `get_referenced_snippets`，让 AI 读取用户标记的代码片段。
- **Client UI**：`window.__ModuleLoader__.load({ id, factory })` 注册，React 通过 `require("react")` 获取，slot 通过 `ctx.get("slots")` 注册（`shell.overlay`），样式用 `--dsw-alias-*` 主题变量。

## 二次开发

- `lib/index.js`：改文件读写、引用/备注存储、或新增 RPC 端点（在 `connection.rpc.handle` 的 handler 里加 `if (endpoint === ...)`）
- `lib/client.js`：改编辑器 UI 布局、配色（`styles` 模板串里的 CSS）、或新增右键菜单项
- 引用/备注数据存模块内存（运行期有效，重启清空）

## 发布

```bash
npm publish --dry-run
npm publish
```

发布前确认 `name` 未被占用，必要时改为 scope 如 `@yourname/dsh-code-ui`。

## 更新日志

> 约定：每次版本升级在本节顶部追加一行（时间 | 版本 | 修复/新增内容）。

| 时间 | 版本 | 修复 / 新增 |
| --- | --- | --- |
| 2026-09-02 | v1.2.0 | 里程碑：双布局与全面可配置。新增右侧停靠布局（code UI 固定占右侧、DSH 界面推到左侧并排，Cursor 式；左缘拖拽实时调宽，壳层帧用 [data-slot=root] 语义属性定位 + 内联 margin-right 推挤）；插件卡片新增「布局模式」（右侧停靠=默认 / 悬浮窗口）、「界面模式」（code UI / dsh UI，状态持久化、所有入口同步记忆）、「切换按钮」（会话头 ⌨ 按钮=默认 / 悬浮模式条，与布局任意组合），全部即时生效 + 持久化；文件树侧栏可收起（« / 📁 三态 / 拖窄收起）+ » 展开把手 + 右缘拖宽；侧栏标题不折行；停靠面板去投影；界面文案更名（Code UI→code UI、原始风格-ui→dsh UI）；悬浮布局也获得侧栏收起/调宽能力 |
| 2026-09-02 | v1.2.0-beta.1 | 里程碑：右侧停靠模式（feature/native-layout 分支）--会话头「⌨ Code UI」开关按钮，Code UI 固定占右侧、DSH 界面推到左侧并排（Cursor 式布局）；左缘拖拽实时调宽；文件树侧栏可收起（« 按钮 / 📁 三态 / 拖到最窄松手收起）+ » 展开把手 + 右缘拖拽调宽；侧栏标题不折行；移除停靠面板投影。推挤采用 [data-slot=root] 语义属性 + 内联 margin-right，不依赖哈希类名 |
| 2026-09-01 | v1.1.10 | 调整：底部状态栏不再用反色按钮样式，改用输入框同款背景（bg-overlay）+ 次要文字色 + 顶部分隔线，深浅色模式下均与编辑器融为一体 |
| 2026-09-01 | v1.1.9 | 修复：反色按钮文字色随主题反转（浅色=黑底白字 / 深色=白底黑字）——选中模式标签、发送按钮、状态栏等此前文字硬编码白色，DSH 深色下 brand-primary 为近白导致白底白字不可见；语法高亮 token 色改为随主题两套配色（浅色背景不再看不清代码）；「跟随 DSH」模式下实时监听宿主外观切换 token 色 |
| 2026-09-01 | v1.1.8 | 修复：主题默认值改为「跟随 DSH」（恢复随宿主外观的原行为，避免系统浅色+DSH 深色时编辑器意外变浅色）；补上文件树/标签栏遗漏的 --dsw-specific-sidebar-fill 变量（修复"只有目录是深色"的混色）；主题选项变四态：跟随 DSH / 跟随系统 / 浅色 / 深色 |
| 2026-09-01 | v1.1.7 | 新增：编辑器主题三模式（浅色/深色/跟随系统）--卡片内切换、即时生效、局部换肤不影响 DSH 其他界面、跟随系统实时响应 OS 外观；仓库公开化清理并重建 git 历史（.git 曾被意外重置，代码无损） |
| 2026-08-31 | v1.1.6 | 新增：外部修改自动同步--host 端 fs.watch 监听已打开文件，编辑器 1 秒内自动刷新；有未保存修改时标 ⚡ 徽标手动加载；自写保存回声抑制 |
| 2026-08-31 | v1.1.5 | 新增：无会话时输入框给出明确提示（常驻警告行 + 置灰按钮点击弹原因 + Ctrl+Enter 兜底提示） |
| 2026-08-28 | v1.1.4 | 新增：卡片内编辑器启用/禁用开关，切换即时挂载/卸载（无需重启/刷新），状态持久化 |
| 2026-08-28 | v1.1.3 | 改进：引用/翻译统一标签制--翻译引用加 🌐 标签，引用不再把代码正文粘贴进消息，AI 经工具读取 |
| 2026-08-28 | v1.1.2 | 改进：插件配置卡片样式与宿主卡片（PluginCard/fields）逐条统一 |
| 2026-08-28 | v1.1.1 | 修复：插件配置卡片不显示--补 host 端 settings 命名空间注册 + client inject 边 |
| 2026-08-27 | v1.1.0 | 新增：检查更新 / 一键更新 / 本地包安装（pnpm 流式进度、失败诊断、防降级） |
| 2026-08-27 | v1.0.1 | 改进：标准化 npm 插件包结构（dsh.bundle 声明、可 `dsh plugin add` 安装） |
| 2026-08-26 | v1.0.0 | 初版：Cursor 风格工作区（文件树、多标签、语法高亮、引用/备注/翻译、内嵌 AI 输入框） |

## License

MIT
