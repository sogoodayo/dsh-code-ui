# dsh-code-ui

A **Cursor-style AI code editor** inside DeepSeek Harness (DSH): file tree, multi-tab editing, syntax highlighting, and "cite/translate a selection to AI".

Bring the "read code, chat with AI" flow into DSH: a code workspace with an activity bar, file-tree sidebar, multi-tab editor, and an embedded AI input at the bottom.

## Install

```bash
dsh plugin --profile web add dsh-code-ui
```

Restart DSH, then click the floating **`Code UI`** / `default-ui` toggle at the top to enter the editor.

## Usage

1. Open the editor via the top `Code UI` toggle.
2. Open a file from the tree or the file picker.
3. Right-click a selection: copy / add note / translate / cite to AI.
4. Type in the bottom input (Ctrl+Enter to send); cited code is attached automatically.
5. Or say "read my cited code" and the AI will call the `get_referenced_snippets` tool.

## Layout

```
dsh-code-ui/
├── package.json      # dsh.bundle.patch / dsh.client manifest
├── lib/
│   ├── index.js      # Host: connection.rpc file/reference/note endpoints + tool
│   └── client.js     # Client: __ModuleLoader__ + editor UI
└── cordis.patch.yml  # bundle patch layer
```

Hand-written JavaScript — no build step, `npm publish` directly.

## License

MIT
